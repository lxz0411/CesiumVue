<template>
  <div class="orbit-controls">
    <div class="control-panel">
      <div class="header-section">
        <h3>轨道显示控制</h3>
        <button class="quick-load-btn" @click="loadOrbitData" :disabled="loading">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
          </svg>
          {{ loading ? '加载中...' : '加载轨道' }}
        </button>
      </div>
      <div class="control-group">
        <label>
          <input type="checkbox" v-model="showOrbit" @change="toggleOrbit" />
          显示轨道
        </label>
      </div>
      <div class="control-group">
        <label>
          <input type="checkbox" v-model="showSatellite" @change="toggleSatellite" />
          显示卫星
        </label>
      </div>
      <div class="control-group">
        <label>
          轨道颜色:
          <input type="color" v-model="orbitColor" @change="updateOrbitColor" />
        </label>
      </div>
      <div class="control-group">
        <label>
          轨道宽度:
          <input type="range" min="1" max="10" v-model="orbitWidth" @change="updateOrbitWidth" />
          {{ orbitWidth }}px
        </label>
      </div>
      
      <div class="control-group">
        <label>
          轨道透明度:
          <input type="range" min="0.1" max="1" step="0.1" v-model="orbitOpacity" @change="updateOrbitOpacity" />
          {{ Math.round(orbitOpacity * 100) }}%
        </label>
      </div>
      <div class="control-group">
        <label>
          选择卫星:
          <select v-model="selectedSatelliteIndex" @change="loadSelectedSatellite" :disabled="loading">
            <option value="-1">请选择卫星</option>
            <option v-for="(satellite, index) in satelliteList" :key="index" :value="index">
              {{ satellite.sateName }} ({{ satellite.sateId }})
            </option>
          </select>
        </label>
      </div>

      <div class="control-group">
        <button @click="testDataLoad" :disabled="loading">
          测试数据加载
        </button>
      </div>
      
      <div class="control-group">
        <button @click="testSimpleConversion" :disabled="loading">
          测试简化转换
        </button>
      </div>
      
      <div class="control-group">
        <button @click="testBasicLoad" :disabled="loading">
          测试基础加载
        </button>
      </div>
      
      <div class="control-group">
        <button @click="testModelLoad" :disabled="loading">
          测试模型加载
        </button>
      </div>
      
      <div class="control-group">
        <button @click="testPointDisplay" :disabled="loading">
          测试点显示
        </button>
      </div>
      
      <div class="control-group" v-if="satelliteEntity">
        <button @click="forceShowPoint" :disabled="loading">
          强制显示卫星点
        </button>
      </div>
      
      <div class="control-group" v-if="satelliteEntity">
        <label>
          <input type="checkbox" v-model="isPlaying" @change="toggleAnimation" />
          播放动画
        </label>
      </div>
      
      <div class="control-group" v-if="satelliteEntity">
        <label>
          播放速度:
          <input type="range" min="0.1" max="10" step="0.1" v-model="playbackSpeed" @change="updatePlaybackSpeed" />
          {{ playbackSpeed }}x
        </label>
      </div>
      
      <div class="control-group" v-if="satelliteEntity">
        <button @click="resetAnimation" :disabled="loading">
          重置动画
        </button>
      </div>
      
      <div class="control-group">
        <button @click="resetCamera" :disabled="loading">
          重置视角
        </button>
      </div>
      
      <div class="control-group">
        <label>
          <input type="checkbox" v-model="trackOrbit" @change="toggleOrbitTracking" />
          跟踪轨道
        </label>
      </div>
      
      <div class="control-group" v-if="satelliteEntity">
        <label>
          卫星大小:
          <input type="range" min="0.5" max="5" step="0.1" v-model="satelliteScale" @change="updateSatelliteScale" />
          {{ satelliteScale }}x
        </label>
      </div>
      
      <div class="control-group">
        <label>
          <input type="checkbox" v-model="showOrbitTrail" @change="toggleOrbitTrail" />
          显示轨道轨迹
        </label>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import * as Cesium from 'cesium'

// 响应式数据
const showOrbit = ref(false)
const showSatellite = ref(false)
const orbitColor = ref('#0066ff')
const orbitWidth = ref(3)
const loading = ref(false)
const selectedSatelliteIndex = ref(-1)
const satelliteList = ref([])
const isPlaying = ref(false)
const playbackSpeed = ref(1.0)
const orbitOpacity = ref(1.0)
const satelliteScale = ref(1.0)
const showOrbitTrail = ref(true)
const trackOrbit = ref(false)

// Cesium相关变量
let viewer = null
let orbitEntity = null
let satelliteEntity = null

// 获取viewer实例
const getViewer = () => {
  console.log('getViewer 被调用')
  console.log('window.cesiumViewer 存在:', !!window.cesiumViewer)
  if (window.cesiumViewer) {
    console.log('返回 viewer 实例')
    return window.cesiumViewer
  }
  console.log('viewer 实例不存在，返回 null')
  return null
}

// J2000 ECI坐标系到ECEF坐标系的转换
const convertECIToECEF = (eciPosition, epoch) => {
  try {
    console.log('开始ECI到ECEF转换:', {eciPosition, epoch})
    
    // 修复时间格式：将 '2025-06-26 00:00:00.000' 转换为 '2025-06-26T00:00:00.000Z'
    let iso8601Epoch = epoch
    if (epoch.includes(' ') && !epoch.includes('T')) {
      iso8601Epoch = epoch.replace(' ', 'T') + 'Z'
    }
    console.log('修复后的时间格式:', iso8601Epoch)
    
    // 使用Cesium的JulianDate来处理时间
    const julianDate = Cesium.JulianDate.fromIso8601(iso8601Epoch)
    console.log('JulianDate:', julianDate)
    
    // 计算从J2000.0到当前时间的儒略世纪数
    const j2000JulianDate = Cesium.JulianDate.fromIso8601('2000-01-01T12:00:00.000Z')
    const daysSinceJ2000 = Cesium.JulianDate.daysDifference(julianDate, j2000JulianDate)
    const centuriesSinceJ2000 = daysSinceJ2000 / 36525.0
    
    console.log('时间计算:', {daysSinceJ2000, centuriesSinceJ2000})
    
    // 计算格林威治平恒星时（GMST）
    // 使用IAU 2000A模型
    const gmst = 24110.54841 + 8640184.812866 * centuriesSinceJ2000 + 
                 0.093104 * Math.pow(centuriesSinceJ2000, 2) - 
                 6.2e-6 * Math.pow(centuriesSinceJ2000, 3)
    
    // 转换为弧度
    const gmstRad = (gmst / 86400.0) * 2 * Math.PI
    const gmstNormalized = gmstRad % (2 * Math.PI)
    
    console.log('GMST计算:', {gmst, gmstRad, gmstNormalized})
    
    // 简化的岁差计算（对于短期轨道数据，岁差影响较小）
    const precessionAngle = 0.013969 * centuriesSinceJ2000 // 简化的岁差角度（弧度）
    
    // 构建岁差矩阵（简化版本）
    const cosPrecession = Math.cos(precessionAngle)
    const sinPrecession = Math.sin(precessionAngle)
    
    const precessionMatrix = new Cesium.Matrix3(
      cosPrecession, -sinPrecession, 0,
      sinPrecession, cosPrecession, 0,
      0, 0, 1
    )
    
    // 应用岁差变换
    const precessedPosition = Cesium.Matrix3.multiplyByVector(precessionMatrix, eciPosition, new Cesium.Cartesian3())
    console.log('岁差变换后:', precessedPosition)
    
    // 应用地球自转（从ECI到ECEF）
    const cosGMST = Math.cos(gmstNormalized)
    const sinGMST = Math.sin(gmstNormalized)
    
    const rotationMatrix = new Cesium.Matrix3(
      cosGMST, sinGMST, 0,
      -sinGMST, cosGMST, 0,
      0, 0, 1
    )
    
    // 应用自转矩阵
    const ecefPosition = Cesium.Matrix3.multiplyByVector(rotationMatrix, precessedPosition, new Cesium.Cartesian3())
    console.log('最终ECEF位置:', ecefPosition)
    
    return ecefPosition
    
  } catch (error) {
    console.error('ECI到ECEF转换失败:', error)
    console.error('错误详情:', error)
    console.error('输入参数:', {eciPosition, epoch})
    // 如果转换失败，返回原始位置（作为备选）
    return eciPosition
  }
}

// 加载轨道数据
const loadOrbitData = async () => {
  loading.value = true
  try {
    console.log('开始加载轨道数据...')
    const response = await fetch('/data/satellites.json')
    console.log('响应状态:', response.status, response.statusText)
    
    if (!response.ok) {
      throw new Error(`HTTP错误: ${response.status} ${response.statusText}`)
    }
    
    const data = await response.json()
    console.log('轨道数据加载成功:', data)
    console.log('数据结构:', {
      hasSatePVList: !!data.satePVList,
      satePVListLength: data.satePVList ? data.satePVList.length : 0,
      firstSatellite: data.satePVList && data.satePVList[0] ? {
        sateId: data.satePVList[0].sateId,
        sateName: data.satePVList[0].sateName,
        pointListLength: data.satePVList[0].pointList ? data.satePVList[0].pointList.length : 0
      } : null
    })
    
    // 保存卫星列表
    if (data.satePVList && data.satePVList.length > 0) {
      satelliteList.value = data.satePVList
      console.log('找到', data.satePVList.length, '个卫星')
      
      // 默认加载第一个卫星
      selectedSatelliteIndex.value = 0
      loadSelectedSatellite()
    } else {
      alert('未找到卫星轨道数据')
    }
  } catch (error) {
    console.error('加载轨道数据失败:', error)
    console.error('错误详情:', {
      name: error.name,
      message: error.message,
      stack: error.stack
    })
    alert(`加载轨道数据失败: ${error.message}`)
  } finally {
    loading.value = false
  }
}

// 加载选中的卫星
const loadSelectedSatellite = () => {
  console.log('loadSelectedSatellite 被调用')
  console.log('selectedSatelliteIndex:', selectedSatelliteIndex.value)
  console.log('satelliteList.length:', satelliteList.value.length)
  
  // 如果选择了"请选择卫星"或没有卫星列表，清理实体并退出
  if (selectedSatelliteIndex.value === -1 || !satelliteList.value.length) {
    console.log('清理之前的实体并退出')
    // 清理之前的实体
    viewer = getViewer()
    if (viewer) {
      if (orbitEntity) {
        viewer.entities.remove(orbitEntity)
        orbitEntity = null
      }
      if (satelliteEntity) {
        viewer.entities.remove(satelliteEntity)
        satelliteEntity = null
      }
    }
    return
  }
  
  // 检查索引是否有效
  if (selectedSatelliteIndex.value < 0 || selectedSatelliteIndex.value >= satelliteList.value.length) {
    console.error('无效的卫星索引:', selectedSatelliteIndex.value)
    return
  }
  
  // 清理之前的实体
  viewer = getViewer()
  if (viewer) {
    console.log('清理之前的实体')
    if (orbitEntity) {
      viewer.entities.remove(orbitEntity)
      orbitEntity = null
    }
    if (satelliteEntity) {
      viewer.entities.remove(satelliteEntity)
      satelliteEntity = null
    }
  }
  
  const selectedSatellite = satelliteList.value[selectedSatelliteIndex.value]
  console.log('使用卫星:', selectedSatellite.sateName, 'ID:', selectedSatellite.sateId)
  console.log('轨道点数量:', selectedSatellite.pointList ? selectedSatellite.pointList.length : 0)
  
  // 转换轨道数据为Cesium格式
  const positions = convertOrbitDataToPositions(selectedSatellite.pointList)
  console.log('转换后的位置数量:', positions.length)
  
  if (positions.length === 0) {
    console.error('没有有效的轨道位置数据')
    alert('轨道数据转换失败，没有有效的位置点')
    return
  }
  
  // 创建轨道实体
  createOrbitEntity(positions, selectedSatellite.sateName)
  
  // 创建卫星实体
  createSatelliteEntity(positions, selectedSatellite.sateName)
  
  // 不改变相机视角，保持地球在屏幕中央
  // 只加载轨道和卫星，让用户自己调整视角
  console.log('轨道和卫星已加载，地球保持在屏幕中央')
}

// 测试数据加载
const testDataLoad = async () => {
  console.log('=== 开始测试数据加载 ===')
  try {
    console.log('1. 测试fetch...')
    const response = await fetch('/data/satellites.json')
    console.log('2. 响应状态:', response.status, response.statusText)
    
    if (!response.ok) {
      throw new Error(`HTTP错误: ${response.status} ${response.statusText}`)
    }
    
    console.log('3. 解析JSON...')
    const data = await response.json()
    console.log('4. 数据解析成功')
    console.log('5. 数据结构:', {
      hasSatePVList: !!data.satePVList,
      satePVListLength: data.satePVList ? data.satePVList.length : 0
    })
    
    if (data.satePVList && data.satePVList.length > 0) {
      const firstSat = data.satePVList[0]
      console.log('6. 第一个卫星:', firstSat.sateName, firstSat.sateId)
      console.log('7. 轨道点数量:', firstSat.pointList ? firstSat.pointList.length : 0)
      
      if (firstSat.pointList && firstSat.pointList[0]) {
        const point = firstSat.pointList[0]
        console.log('8. 第一个点:', point)
        
        // 测试坐标转换
        console.log('9. 测试坐标转换...')
        const eciPosition = new Cesium.Cartesian3(point.x, point.y, point.z)
        const ecefPosition = convertECIToECEF(eciPosition, point.epoch)
        const cartographic = Cesium.Cartographic.fromCartesian(ecefPosition)
        console.log('10. 转换成功:', {
          original: {x: point.x, y: point.y, z: point.z},
          ecef: {x: ecefPosition.x, y: ecefPosition.y, z: ecefPosition.z},
          geographic: {
            longitude: Cesium.Math.toDegrees(cartographic.longitude),
            latitude: Cesium.Math.toDegrees(cartographic.latitude),
            height: cartographic.height
          }
        })
      }
    }
    
    console.log('=== 测试完成，所有步骤成功 ===')
    alert('测试成功！请查看控制台日志')
    
  } catch (error) {
    console.error('=== 测试失败 ===', error)
    alert(`测试失败: ${error.message}`)
  }
}

// 测试简化转换
const testSimpleConversion = async () => {
  console.log('=== 开始测试简化转换 ===')
  try {
    const response = await fetch('/data/satellites.json')
    const data = await response.json()
    
    if (data.satePVList && data.satePVList.length > 0) {
      const firstSat = data.satePVList[0]
      console.log('测试卫星:', firstSat.sateName)
      
      // 只测试前5个点
      const testPoints = firstSat.pointList.slice(0, 5)
      console.log('测试点数量:', testPoints.length)
      
      testPoints.forEach((point, index) => {
        console.log(`\n--- 测试点 ${index} ---`)
        console.log('原始数据:', point)
        
        // 直接使用ECI坐标（假设已经是ECEF格式）
        const position = new Cesium.Cartesian3(point.x, point.y, point.z)
        const cartographic = Cesium.Cartographic.fromCartesian(position)
        
        console.log('转换结果:', {
          longitude: Cesium.Math.toDegrees(cartographic.longitude),
          latitude: Cesium.Math.toDegrees(cartographic.latitude),
          height: cartographic.height
        })
        
        // 检查结果是否合理
        if (isNaN(cartographic.longitude) || isNaN(cartographic.latitude) || isNaN(cartographic.height)) {
          console.error('转换结果包含NaN值')
        } else if (cartographic.height < 0 || cartographic.height > 100000000) {
          console.warn('高度值异常:', cartographic.height)
        } else {
          console.log('转换结果正常')
        }
      })
    }
    
    console.log('=== 简化转换测试完成 ===')
    alert('简化转换测试完成！请查看控制台日志')
    
  } catch (error) {
    console.error('=== 简化转换测试失败 ===', error)
    alert(`简化转换测试失败: ${error.message}`)
  }
}

// 测试基础加载
const testBasicLoad = async () => {
  console.log('=== 开始测试基础加载 ===')
  try {
    console.log('1. 开始fetch请求...')
    const response = await fetch('/data/satellites.json')
    console.log('2. 响应状态:', response.status, response.statusText)
    
    if (!response.ok) {
      throw new Error(`HTTP错误: ${response.status} ${response.statusText}`)
    }
    
    console.log('3. 开始解析JSON...')
    const data = await response.json()
    console.log('4. JSON解析成功')
    
    console.log('5. 数据结构检查:')
    console.log('- 是否有satePVList:', !!data.satePVList)
    console.log('- satePVList类型:', typeof data.satePVList)
    console.log('- satePVList长度:', data.satePVList ? data.satePVList.length : 'undefined')
    
    if (data.satePVList && data.satePVList.length > 0) {
      const firstSat = data.satePVList[0]
      console.log('6. 第一个卫星信息:')
      console.log('- 卫星名称:', firstSat.sateName)
      console.log('- 卫星ID:', firstSat.sateId)
      console.log('- 是否有pointList:', !!firstSat.pointList)
      console.log('- pointList类型:', typeof firstSat.pointList)
      console.log('- pointList长度:', firstSat.pointList ? firstSat.pointList.length : 'undefined')
      
      if (firstSat.pointList && firstSat.pointList.length > 0) {
        const firstPoint = firstSat.pointList[0]
        console.log('7. 第一个轨道点:')
        console.log('- epoch:', firstPoint.epoch)
        console.log('- x:', firstPoint.x)
        console.log('- y:', firstPoint.y)
        console.log('- z:', firstPoint.z)
        console.log('- vx:', firstPoint.vx)
        console.log('- vy:', firstPoint.vy)
        console.log('- vz:', firstPoint.vz)
        
        // 测试最简单的转换
        console.log('8. 测试最简单转换...')
        try {
          const position = new Cesium.Cartesian3(firstPoint.x, firstPoint.y, firstPoint.z)
          console.log('Cartesian3创建成功:', position)
          
          const cartographic = Cesium.Cartographic.fromCartesian(position)
          console.log('地理坐标转换成功:', cartographic)
          
          console.log('最终结果:', {
            longitude: Cesium.Math.toDegrees(cartographic.longitude),
            latitude: Cesium.Math.toDegrees(cartographic.latitude),
            height: cartographic.height
          })
        } catch (conversionError) {
          console.error('转换失败:', conversionError)
        }
      } else {
        console.error('第一个卫星没有pointList数据')
      }
    } else {
      console.error('没有找到卫星数据')
    }
    
    console.log('=== 基础加载测试完成 ===')
    alert('基础加载测试完成！请查看控制台日志')
    
  } catch (error) {
    console.error('=== 基础加载测试失败 ===', error)
    console.error('错误详情:', error)
    alert(`基础加载测试失败: ${error.message}`)
  }
}

// 测试模型加载
const testModelLoad = async () => {
  console.log('=== 开始测试模型加载 ===')
  try {
    viewer = getViewer()
    if (!viewer) {
      throw new Error('无法获取Cesium viewer实例')
    }
    
    console.log('1. 测试模型文件访问...')
    const modelResponse = await fetch('/model/satellite.glb')
    console.log('2. 模型文件响应状态:', modelResponse.status, modelResponse.statusText)
    
    if (!modelResponse.ok) {
      throw new Error(`模型文件访问失败: ${modelResponse.status} ${modelResponse.statusText}`)
    }
    
    console.log('3. 模型文件存在，开始创建测试实体...')
    
    let testEntity = null
    
    try {
      // 尝试创建模型实体
      testEntity = viewer.entities.add({
        name: '测试卫星模型',
        position: Cesium.Cartesian3.fromDegrees(0, 0, 1000000), // 1000km高度
        model: {
          uri: '/model/satellite.glb',
          scale: 1000,
          minimumPixelSize: 32,
          maximumScale: 2000,
          heightReference: Cesium.HeightReference.NONE,
          show: true
        }
      })
      
      console.log('4. 测试实体创建成功:', testEntity)
      console.log('模型属性:', testEntity.model)
      console.log('模型URI:', testEntity.model ? testEntity.model.uri : 'undefined')
      
    } catch (entityError) {
      console.error('实体创建失败:', entityError)
      throw new Error(`实体创建失败: ${entityError.message}`)
    }
    
    // 检查模型属性
    if (testEntity.model) {
      console.log('5. 模型属性存在，检查readyPromise...')
      
      if (testEntity.model.readyPromise) {
        console.log('6. 开始监听模型加载...')
        testEntity.model.readyPromise.then(() => {
          console.log('✅ 测试模型加载成功！')
          alert('模型加载成功！请查看场景中的测试卫星')
        }).catch((error) => {
          console.error('❌ 测试模型加载失败:', error)
          alert(`模型加载失败: ${error.message}`)
          // 清理测试实体
          if (testEntity) {
            viewer.entities.remove(testEntity)
          }
        })
      } else {
        console.warn('⚠️ 模型readyPromise不存在，可能是不支持的格式')
        console.warn('模型属性详情:', testEntity.model)
        
        // 尝试直接显示模型
        try {
          if (testEntity.model) {
            testEntity.model.show = true
            console.log('✅ 直接显示模型成功')
            alert('模型创建成功！readyPromise不存在但模型已显示，请查看场景中的测试卫星')
            
            // 等待一段时间后检查模型是否真的显示了
            setTimeout(() => {
              if (testEntity.model && testEntity.model.show) {
                console.log('✅ 测试模型显示确认成功')
              } else {
                console.warn('⚠️ 测试模型可能没有正确显示')
                alert('测试模型可能没有正确显示，请检查控制台')
              }
            }, 2000) // 等待2秒
            
          }
        } catch (error) {
          console.error('直接显示模型失败:', error)
          alert(`模型显示失败: ${error.message}`)
          if (testEntity) {
            viewer.entities.remove(testEntity)
          }
        }
      }
    } else {
      console.error('❌ 模型属性不存在')
      alert('模型属性创建失败')
      if (testEntity) {
        viewer.entities.remove(testEntity)
      }
    }
    
  } catch (error) {
    console.error('=== 模型加载测试失败 ===', error)
    alert(`模型加载测试失败: ${error.message}`)
  }
}

// 测试点显示
const testPointDisplay = async () => {
  console.log('=== 开始测试点显示 ===')
  try {
    viewer = getViewer()
    if (!viewer) {
      throw new Error('无法获取Cesium viewer实例')
    }
    
    console.log('1. 创建测试点实体...')
    
    // 创建一个简单的点实体
    const testPointEntity = viewer.entities.add({
      name: '测试点',
      position: Cesium.Cartesian3.fromDegrees(0, 0, 1000000), // 1000km高度
      point: {
        pixelSize: 30, // 很大的点
        color: Cesium.Color.RED,
        outlineColor: Cesium.Color.YELLOW,
        outlineWidth: 5,
        heightReference: Cesium.HeightReference.NONE,
        show: true
      },
      label: {
        text: '测试点',
        font: '16pt sans-serif',
        fillColor: Cesium.Color.YELLOW,
        outlineColor: Cesium.Color.RED,
        outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new Cesium.Cartesian2(0, -50),
        heightReference: Cesium.HeightReference.NONE,
        show: true
      }
    })
    
    console.log('2. 测试点实体创建成功:', testPointEntity)
    console.log('点属性:', testPointEntity.point)
    console.log('点显示状态:', testPointEntity.point ? testPointEntity.point.show : '无点属性')
    
    alert('测试点已创建！请查看场景中是否有一个红色的大圆点')
    
    // 5秒后清理测试点
    setTimeout(() => {
      viewer.entities.remove(testPointEntity)
      console.log('测试点已清理')
    }, 5000)
    
  } catch (error) {
    console.error('=== 点显示测试失败 ===', error)
    alert(`点显示测试失败: ${error.message}`)
  }
}

// 强制显示卫星点
const forceShowPoint = () => {
  console.log('=== 强制显示卫星点 ===')
  
  if (!satelliteEntity) {
    console.error('没有卫星实体')
    alert('没有卫星实体，请先加载轨道')
    return
  }
  
  console.log('当前卫星实体状态:', {
    hasModel: !!satelliteEntity.model,
    hasPoint: !!satelliteEntity.point,
    modelShow: satelliteEntity.model ? satelliteEntity.model.show : '无模型',
    pointShow: satelliteEntity.point ? satelliteEntity.point.show : '无点'
  })
  
  // 强制显示点
  if (satelliteEntity.point) {
    satelliteEntity.point.show = true
    satelliteEntity.point.pixelSize = 25 // 增大点的大小
    console.log('✅ 强制显示点成功')
    console.log('点显示状态:', satelliteEntity.point.show)
    console.log('点大小:', satelliteEntity.point.pixelSize)
  } else {
    console.error('❌ 卫星实体没有点属性')
    alert('卫星实体没有点属性')
  }
  
  // 隐藏模型（如果存在）
  if (satelliteEntity.model) {
    satelliteEntity.model.show = false
    console.log('隐藏模型')
  }
  
  // 强制刷新场景
  viewer.scene.requestRender()
  
  alert('已强制显示卫星点！请查看场景')
}

// 转换轨道数据为Cesium位置格式
const convertOrbitDataToPositions = (pointList) => {
  const positions = []
  
  if (!pointList || !Array.isArray(pointList)) {
    console.error('pointList 不是有效的数组:', pointList)
    return positions
  }
  
  console.log('开始转换轨道数据，点数量:', pointList.length)
  console.log('前3个点的原始数据:', pointList.slice(0, 3))
  
  // 使用简化的转换方法，避免复杂的J2000转换
  pointList.forEach((point, index) => {
    try {
      // 检查必要字段
      if (point.x === undefined || point.x === null || !point.epoch) {
        console.warn(`跳过无效点 ${index}:`, point)
        return
      }
      
      const x = point.x || 0
      const y = point.y || 0
      const z = point.z || 0
      
      // 检查坐标是否有效（不能全为0）
      if (x === 0 && y === 0 && z === 0) {
        console.warn(`跳过零坐标点 ${index}`)
        return
      }
      
      if (index < 3) { // 只打印前3个点的详细信息
        console.log(`处理点 ${index}:`, {x, y, z, epoch: point.epoch})
      }
      
      // 使用简化的转换方法：直接假设数据是ECEF格式
      const position = new Cesium.Cartesian3(x, y, z)
      const cartographic = Cesium.Cartographic.fromCartesian(position)
      
      if (!cartographic) {
        console.warn(`坐标转换失败，跳过点 ${index}:`, point)
        return
      }
      
      // 检查转换后的坐标是否有效
      if (isNaN(cartographic.longitude) || isNaN(cartographic.latitude) || isNaN(cartographic.height)) {
        console.warn(`转换后坐标无效，跳过点 ${index}:`, {
          longitude: cartographic.longitude,
          latitude: cartographic.latitude,
          height: cartographic.height
        })
        return
      }
      
      // 放宽高度检查范围
      if (cartographic.height < -1000000 || cartographic.height > 100000000) {
        console.warn(`高度异常，跳过点 ${index}:`, cartographic.height)
        return
      }
      
      // 修复时间格式
      let iso8601Epoch = point.epoch
      if (point.epoch.includes(' ') && !point.epoch.includes('T')) {
        iso8601Epoch = point.epoch.replace(' ', 'T') + 'Z'
      }
      
      positions.push({
        longitude: cartographic.longitude,
        latitude: cartographic.latitude,
        height: cartographic.height,
        time: Cesium.JulianDate.fromIso8601(iso8601Epoch),
        // 保存原始ECI坐标用于调试
        originalPosition: { x, y, z }
      })
      
      if (index < 3) { // 只打印前3个点的详细信息
        console.log(`点 ${index} 转换成功:`, {
          epoch: point.epoch,
          original: {x, y, z},
          converted: {
            longitude: Cesium.Math.toDegrees(cartographic.longitude),
            latitude: Cesium.Math.toDegrees(cartographic.latitude),
            height: cartographic.height
          }
        })
      }
    } catch (error) {
      console.error(`转换点 ${index} 时出错:`, error, point)
    }
  })
  
  console.log('转换完成，有效位置数量:', positions.length)
  if (positions.length === 0) {
    console.error('没有成功转换任何位置点！')
    console.error('可能的原因:')
    console.error('1. 数据格式不正确')
    console.error('2. 坐标值超出有效范围')
    console.error('3. 时间格式不正确')
  }
  return positions
}

// 创建轨道实体
const createOrbitEntity = (positions, satelliteName) => {
  console.log('createOrbitEntity 被调用')
  viewer = getViewer()
  if (!viewer) {
    console.error('无法获取viewer实例')
    return
  }
  
  console.log('创建轨道实体，位置数量:', positions.length)
  
  // 移除现有轨道
  if (orbitEntity) {
    console.log('移除现有轨道实体')
    viewer.entities.remove(orbitEntity)
  }
  
  // 创建时间属性数组
  const timePositions = positions.map(pos => ({
    time: pos.time,
    position: Cesium.Cartesian3.fromRadians(pos.longitude, pos.latitude, pos.height)
  }))
  
  console.log('轨道显示状态:', showOrbit.value)
  console.log('轨道颜色:', orbitColor.value)
  console.log('轨道宽度:', orbitWidth.value)
  
  // 创建轨道实体 - 使用更高级的材质
  const color = Cesium.Color.fromCssColorString(orbitColor.value)
  color.alpha = orbitOpacity.value
  
  orbitEntity = viewer.entities.add({
    name: `${satelliteName}轨道`,
    polyline: {
      positions: timePositions.map(tp => tp.position),
      width: orbitWidth.value,
      material: new Cesium.PolylineGlowMaterialProperty({
        glowPower: 0.3,
        color: color
      }),
      clampToGround: false,
      show: true,  // 默认显示轨道
      // 添加深度测试，确保轨道在正确位置显示
      depthFailMaterial: color.withAlpha(0.3)
    }
  })
  
  console.log('轨道实体创建成功:', orbitEntity)
  
  // 检查实体是否真的被添加到场景中
  setTimeout(() => {
    const entities = viewer.entities.values
    console.log('场景中的实体数量:', entities.length)
    const orbitEntities = entities.filter(e => e.name && e.name.includes('轨道'))
    console.log('轨道实体数量:', orbitEntities.length)
    if (orbitEntities.length > 0) {
      console.log('轨道实体详情:', orbitEntities[0])
    }
  }, 100)
  
  // 自动勾选显示轨道复选框
  showOrbit.value = true
  
  // 强制刷新场景
  viewer.scene.requestRender()
}

// 创建卫星实体
const createSatelliteEntity = (positions, satelliteName) => {
  console.log('createSatelliteEntity 被调用')
  viewer = getViewer()
  if (!viewer) {
    console.error('无法获取viewer实例')
    return
  }
  
  // 移除现有卫星
  if (satelliteEntity) {
    console.log('移除现有卫星实体')
    viewer.entities.remove(satelliteEntity)
  }
  
  if (positions.length === 0) {
    console.log('没有位置数据，跳过卫星创建')
    return
  }
  
  // 创建时间属性数组
  const timePositions = positions.map(pos => ({
    time: pos.time,
    position: Cesium.Cartesian3.fromRadians(pos.longitude, pos.latitude, pos.height)
  }))
  
  console.log('卫星显示状态:', showSatellite.value)
  
  // 创建卫星实体 - 先尝试使用3D模型
  console.log('开始创建卫星实体...')
  
  try {
    // 尝试创建模型实体
    satelliteEntity = viewer.entities.add({
      name: satelliteName,
      position: timePositions[0].position,
      // 使用3D模型
      model: {
        uri: '/model/satellite.glb',
        scale: 1000, // 缩放模型
        minimumPixelSize: 32, // 最小像素大小
        maximumScale: 2000, // 最大缩放
        heightReference: Cesium.HeightReference.NONE,
        show: true // 默认显示模型
      },
      // 如果模型加载失败，使用点作为备选
      point: {
        pixelSize: 20, // 增大点的大小
        color: Cesium.Color.BLUE,
        outlineColor: Cesium.Color.WHITE,
        outlineWidth: 3,
        heightReference: Cesium.HeightReference.NONE,
        show: true // 默认显示点，等模型加载成功后再隐藏
      },
      // 添加标签显示卫星名称
      label: {
        text: satelliteName,
        font: '12pt sans-serif',
        fillColor: Cesium.Color.LIGHTBLUE,
        outlineColor: Cesium.Color.DARKBLUE,
        outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new Cesium.Cartesian2(0, -40),
        heightReference: Cesium.HeightReference.NONE,
        show: true
      },
      // 添加时间属性用于动画
      availability: new Cesium.TimeIntervalCollection([
        new Cesium.TimeInterval({
          start: timePositions[0].time,
          stop: timePositions[timePositions.length - 1].time
        })
      ])
    })
    
    console.log('卫星实体创建成功，检查模型属性...')
    console.log('模型属性:', satelliteEntity.model)
    console.log('模型URI:', satelliteEntity.model ? satelliteEntity.model.uri : 'undefined')
    console.log('模型show:', satelliteEntity.model ? satelliteEntity.model.show : 'undefined')
    
  } catch (modelError) {
    console.error('模型实体创建失败，使用点实体:', modelError)
    
    // 如果模型创建失败，直接创建点实体
    satelliteEntity = viewer.entities.add({
      name: satelliteName,
      position: timePositions[0].position,
      // 只使用点显示
      point: {
        pixelSize: 20, // 增大点的大小
        color: Cesium.Color.BLUE,
        outlineColor: Cesium.Color.WHITE,
        outlineWidth: 3,
        heightReference: Cesium.HeightReference.NONE,
        show: true
      },
      // 添加标签显示卫星名称
      label: {
        text: satelliteName,
        font: '12pt sans-serif',
        fillColor: Cesium.Color.LIGHTBLUE,
        outlineColor: Cesium.Color.DARKBLUE,
        outlineWidth: 2,
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new Cesium.Cartesian2(0, -40),
        heightReference: Cesium.HeightReference.NONE,
        show: true
      },
      // 添加时间属性用于动画
      availability: new Cesium.TimeIntervalCollection([
        new Cesium.TimeInterval({
          start: timePositions[0].time,
          stop: timePositions[timePositions.length - 1].time
        })
      ])
    })
    
    console.log('点实体创建成功')
  }
  
  // 设置位置属性用于动画
  const positionProperty = new Cesium.SampledPositionProperty()
  timePositions.forEach(tp => {
    positionProperty.addSample(tp.time, tp.position)
  })
  
  satelliteEntity.position = positionProperty
  
  // 设置方向属性，让卫星始终朝向运动方向
  const orientationProperty = new Cesium.VelocityOrientationProperty(positionProperty)
  satelliteEntity.orientation = orientationProperty
  
  // 监听模型加载状态
  console.log('检查模型属性:', {
    hasModel: !!satelliteEntity.model,
    hasReadyPromise: !!(satelliteEntity.model && satelliteEntity.model.readyPromise),
    modelUri: satelliteEntity.model ? satelliteEntity.model.uri : 'undefined'
  })
  
  // 检查是否有模型属性
  if (satelliteEntity.model) {
    console.log('模型属性存在，检查readyPromise...')
    
    // 检查readyPromise是否存在
    if (satelliteEntity.model.readyPromise) {
      console.log('开始监听模型加载状态...')
      satelliteEntity.model.readyPromise.then(() => {
        console.log('✅ 卫星模型加载成功！')
        // 模型加载成功后隐藏点
        if (satelliteEntity.point) {
          satelliteEntity.point.show = false
          console.log('隐藏点显示')
        }
        if (satelliteEntity.model) {
          satelliteEntity.model.show = true
          console.log('显示模型')
        }
      }).catch((error) => {
        console.error('❌ 卫星模型加载失败，使用点显示:', error)
        console.error('错误详情:', {
          name: error.name,
          message: error.message,
          stack: error.stack
        })
        // 模型加载失败后显示点
        if (satelliteEntity.point) {
          satelliteEntity.point.show = true
          console.log('显示点作为备选')
        }
        if (satelliteEntity.model) {
          satelliteEntity.model.show = false
          console.log('隐藏模型')
        }
      })
    } else {
      console.warn('⚠️ 模型readyPromise不存在，可能是不支持的模型格式')
      console.warn('模型属性详情:', satelliteEntity.model)
      
      // 尝试直接显示模型，如果失败则使用点
      try {
        if (satelliteEntity.model) {
          satelliteEntity.model.show = true
          console.log('✅ 直接显示模型成功')
        }
        if (satelliteEntity.point) {
          satelliteEntity.point.show = true // 同时显示点，以防模型失败
          console.log('同时显示点作为备选')
        }
        
        // 立即检查模型是否真的显示了
        setTimeout(() => {
          // 由于GLB格式可能不被支持，直接保持点显示
          console.log('⚠️ GLB格式可能不被支持，保持点显示')
          if (satelliteEntity.point) {
            satelliteEntity.point.show = true
            console.log('保持点显示')
          }
          if (satelliteEntity.model) {
            satelliteEntity.model.show = false
            console.log('隐藏模型')
          }
        }, 500) // 等待0.5秒后立即检查
        
        // 等待一段时间后检查模型是否真的显示了
        setTimeout(() => {
          // 由于GLB格式可能不被支持，始终保持点显示
          console.log('⚠️ GLB格式可能不被支持，始终保持点显示')
          if (satelliteEntity.point) {
            satelliteEntity.point.show = true
            console.log('保持点显示')
          }
          if (satelliteEntity.model) {
            satelliteEntity.model.show = false
            console.log('隐藏模型')
          }
        }, 2000) // 等待2秒
        
      } catch (error) {
        console.error('直接显示模型失败:', error)
        if (satelliteEntity.point) {
          satelliteEntity.point.show = true
          console.log('显示点作为备选')
        }
        if (satelliteEntity.model) {
          satelliteEntity.model.show = false
          console.log('隐藏模型')
        }
      }
    }
  } else {
    console.warn('⚠️ 没有模型属性，使用点显示')
    if (satelliteEntity.point) {
      satelliteEntity.point.show = true
      console.log('显示点')
    }
  }
  
  // 强制确保点显示（作为最后的备选方案）
  setTimeout(() => {
    console.log('检查最终显示状态...')
    console.log('模型显示状态:', satelliteEntity.model ? satelliteEntity.model.show : '无模型')
    console.log('点显示状态:', satelliteEntity.point ? satelliteEntity.point.show : '无点')
    
    // 如果模型和点都没有显示，强制显示点
    const modelVisible = satelliteEntity.model && satelliteEntity.model.show
    const pointVisible = satelliteEntity.point && satelliteEntity.point.show
    
    if (!modelVisible && !pointVisible) {
      console.warn('⚠️ 模型和点都没有显示，强制显示点')
      if (satelliteEntity.point) {
        satelliteEntity.point.show = true
        console.log('强制显示点成功')
      }
    }
  }, 3000) // 等待3秒后检查
  
  console.log('卫星实体创建成功:', satelliteEntity)
  console.log('卫星实体详细信息:', {
    name: satelliteEntity.name,
    position: satelliteEntity.position,
    hasModel: !!satelliteEntity.model,
    hasPoint: !!satelliteEntity.point,
    hasLabel: !!satelliteEntity.label,
    modelShow: satelliteEntity.model ? satelliteEntity.model.show : '无模型',
    pointShow: satelliteEntity.point ? satelliteEntity.point.show : '无点',
    labelShow: satelliteEntity.label ? satelliteEntity.label.show : '无标签'
  })
  
  // 检查实体是否真的被添加到场景中
  setTimeout(() => {
    console.log('检查实体是否被添加到场景中...')
    const entities = viewer.entities.values
    console.log('场景中的实体数量:', entities.length)
    console.log('卫星实体是否在场景中:', entities.includes(satelliteEntity))
    
    const satelliteEntities = entities.filter(e => e.name && !e.name.includes('轨道'))
    console.log('卫星实体数量:', satelliteEntities.length)
    
    if (entities.includes(satelliteEntity)) {
      console.log('✅ 卫星实体已成功添加到场景中')
      
      // 再次检查显示状态
      console.log('再次检查显示状态:')
      console.log('- 模型显示:', satelliteEntity.model ? satelliteEntity.model.show : '无模型')
      console.log('- 点显示:', satelliteEntity.point ? satelliteEntity.point.show : '无点')
      console.log('- 标签显示:', satelliteEntity.label ? satelliteEntity.label.show : '无标签')
      
      // 如果点没有显示，强制显示
      if (satelliteEntity.point && !satelliteEntity.point.show) {
        console.log('强制显示点...')
        satelliteEntity.point.show = true
        console.log('点显示状态已更新:', satelliteEntity.point.show)
      }
      
    } else {
      console.error('❌ 卫星实体没有添加到场景中')
    }
  }, 100)
  
  // 自动勾选显示卫星复选框
  showSatellite.value = true
  
  // 强制刷新场景
  viewer.scene.requestRender()
}

// 切换轨道显示
const toggleOrbit = () => {
  if (orbitEntity) {
    orbitEntity.polyline.show = showOrbit.value && showOrbitTrail.value
  }
}

// 切换卫星显示
const toggleSatellite = () => {
  if (satelliteEntity) {
    // 切换模型显示
    if (satelliteEntity.model) {
      satelliteEntity.model.show = showSatellite.value
    }
    // 切换点显示
    if (satelliteEntity.point) {
      satelliteEntity.point.show = showSatellite.value
    }
    // 切换标签显示
    if (satelliteEntity.label) {
      satelliteEntity.label.show = showSatellite.value
    }
  }
}

// 更新轨道颜色
const updateOrbitColor = () => {
  if (orbitEntity) {
    const color = Cesium.Color.fromCssColorString(orbitColor.value)
    color.alpha = orbitOpacity.value
    orbitEntity.polyline.material = new Cesium.PolylineGlowMaterialProperty({
      glowPower: 0.3,
      color: color
    })
  }
}

// 更新轨道透明度
const updateOrbitOpacity = () => {
  if (orbitEntity) {
    const color = Cesium.Color.fromCssColorString(orbitColor.value)
    color.alpha = orbitOpacity.value
    orbitEntity.polyline.material = new Cesium.PolylineGlowMaterialProperty({
      glowPower: 0.3,
      color: color
    })
  }
}

// 更新轨道宽度
const updateOrbitWidth = () => {
  if (orbitEntity) {
    orbitEntity.polyline.width = orbitWidth.value
  }
}

// 切换动画播放
const toggleAnimation = () => {
  viewer = getViewer()
  if (!viewer) {
    console.error('无法获取viewer实例')
    return
  }
  
  if (isPlaying.value) {
    viewer.clock.shouldAnimate = true
    console.log('开始播放动画')
  } else {
    viewer.clock.shouldAnimate = false
    console.log('暂停动画')
  }
}

// 更新播放速度
const updatePlaybackSpeed = () => {
  viewer = getViewer()
  if (!viewer) {
    console.error('无法获取viewer实例')
    return
  }
  
  viewer.clock.multiplier = playbackSpeed.value
  console.log('播放速度设置为:', playbackSpeed.value)
}

// 重置动画
const resetAnimation = () => {
  viewer = getViewer()
  if (!viewer) {
    console.error('无法获取viewer实例')
    return
  }
  
  // 重置到开始时间
  viewer.clock.currentTime = viewer.clock.startTime.clone()
  isPlaying.value = false
  viewer.clock.shouldAnimate = false
  console.log('动画已重置')
}

// 重置相机视角
const resetCamera = () => {
  viewer = getViewer()
  if (!viewer) {
    console.error('无法获取viewer实例')
    return
  }
  
  // 设置全局视角，地球居中
  viewer.camera.setView({
    destination: Cesium.Cartesian3.fromDegrees(0, 0, 20000000), // 20000km高度
    orientation: {
      heading: 0.0,
      pitch: Cesium.Math.toRadians(-30),
      roll: 0.0
    }
  })
  
  console.log('相机视角已重置到全局视角，地球居中')
}

// 切换轨道跟踪
const toggleOrbitTracking = () => {
  if (trackOrbit.value) {
    // 启用轨道跟踪
    console.log('启用轨道跟踪')
    // 这里可以添加轨道跟踪逻辑，但保持地球居中
  } else {
    // 禁用轨道跟踪，重置到全局视角
    console.log('禁用轨道跟踪')
    resetCamera()
  }
}

// 更新卫星大小
const updateSatelliteScale = () => {
  if (satelliteEntity) {
    if (satelliteEntity.model) {
      satelliteEntity.model.scale = 1000 * satelliteScale.value
      console.log('卫星模型大小设置为:', satelliteScale.value)
    }
    if (satelliteEntity.point) {
      satelliteEntity.point.pixelSize = 16 * satelliteScale.value
      console.log('卫星点大小设置为:', satelliteScale.value)
    }
  }
}

// 切换轨道轨迹显示
const toggleOrbitTrail = () => {
  if (orbitEntity) {
    orbitEntity.polyline.show = showOrbitTrail.value && showOrbit.value
  }
}

onMounted(() => {
  console.log('OrbitDisplay组件已挂载')
  // 等待viewer初始化
  setTimeout(() => {
    console.log('检查viewer初始化状态...')
    viewer = getViewer()
    if (viewer) {
      console.log('OrbitDisplay组件已连接到Cesium viewer')
    } else {
      console.log('警告: 无法获取Cesium viewer实例')
    }
  }, 1000)
})

onBeforeUnmount(() => {
  // 清理实体
  if (viewer) {
    if (orbitEntity) {
      viewer.entities.remove(orbitEntity)
    }
    if (satelliteEntity) {
      viewer.entities.remove(satelliteEntity)
    }
  }
})
</script>

<style scoped>
.orbit-controls {
  position: fixed;
  top: 20px;
  left: 20px;
  z-index: 1000;
}

.control-panel {
  background-color: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 20px;
  border-radius: 8px;
  min-width: 250px;
  font-family: Arial, sans-serif;
  border: 2px solid #0066ff;
  box-shadow: 0 0 20px rgba(0, 102, 255, 0.3);
}

.header-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 15px;
  gap: 10px;
}

.control-panel h3 {
  margin: 0;
  color: #0066ff;
  font-size: 16px;
  flex-shrink: 0;
}

.quick-load-btn {
  background-color: #0066ff;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 13px;
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: 4px;
  transition: all 0.3s ease;
  flex-shrink: 0;
  white-space: nowrap;
}

.quick-load-btn:hover:not(:disabled) {
  background-color: #0052cc;
  transform: translateY(-1px);
}

.quick-load-btn:disabled {
  background-color: #666;
  cursor: not-allowed;
  transform: none;
}

.quick-load-btn svg {
  flex-shrink: 0;
}

.control-group {
  margin-bottom: 15px;
}

.control-group label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.control-group input[type="checkbox"] {
  margin: 0;
  accent-color: #0066ff;
}

.control-group input[type="color"] {
  width: 30px;
  height: 20px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}

.control-group input[type="range"] {
  width: 100px;
  margin: 0 5px;
  accent-color: #0066ff;
}

.control-group select {
  width: 100%;
  padding: 4px 8px;
  border: 1px solid #0066ff;
  border-radius: 4px;
  background-color: white;
  color: black;
  font-size: 14px;
}

.control-group select:focus {
  outline: none;
  border-color: #0052cc;
  box-shadow: 0 0 5px rgba(0, 102, 255, 0.3);
}

.control-group button {
  background-color: #0066ff;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  font-weight: bold;
}

.control-group button:hover:not(:disabled) {
  background-color: #0052cc;
}

.control-group button:disabled {
  background-color: #666;
  cursor: not-allowed;
}
</style>
